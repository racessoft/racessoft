package org.races.controller;

import java.io.BufferedInputStream;   
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.LinkedHashMap;
import java.util.List;

import net.sf.jasperreports.web.servlets.ReportServlet;

import org.apache.log4j.Logger; 
import org.races.Constants.ReportConstants;
import org.races.model.JobCardDetails;
import org.races.model.ReportFilter;
import org.races.model.SoldSpares;
import org.races.service.RacesService;
import org.races.util.FormatType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView; 
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;;

@Controller
public class RacesController {
	@Autowired
	RacesService racesService;
	
    /**
     * class path name of usageTrendChart.jasper(a '.jasper' file to generate
     * usage trend chart).
     */
    @Value("${usageTrend.chart.location}")
    private String usageTrendFile;

	private static Logger log = Logger.getLogger(RacesController.class);
@RequestMapping("getReport.do")
public ModelAndView getReport(HttpServletRequest request, HttpServletResponse response,ReportFilter reportFilter)
{
	ModelAndView mav = null;

	try {
		System.out.println("@ controller.....");
		log.info("Entered getReport ..");
		log.info("Current Date" + reportFilter.getForCurrentMonth());
		String from = reportFilter.getFrom();
		reportFilter.setFormatType(FormatType.HTML);
		byte[] reportArray = racesService.getPendingReport(reportFilter).toByteArray();
		String reportString = new String(reportArray,ReportConstants.CHAR_SET);
		mav = new ModelAndView("racesreport");
		mav.addObject("reportString",reportString);
		mav.addObject("fromParam", from);
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return mav;
} 

@RequestMapping("jobCardReport.do")
public ModelAndView addJobCardReport(HttpServletRequest request, HttpServletResponse response,JobCardDetails jobCardDetails)
{
	ModelAndView mav = null;

	try {
		System.out.println("@ controller.....");
		log.info("Entered jobCardReport ..");
		String from = jobCardDetails.getFrom();
		//reportFilter.setFormatType(FormatType.HTML);
		 LinkedHashMap<String, Float> spareDetail = racesService
                 .getSparesDetails();
		/*byte[] reportArray = racesService.getPendingReport(reportFilter).toByteArray();
		String reportString = new String(reportArray,ReportConstants.CHAR_SET);
		/*mav.addObject("reportString",reportString);*/
		if(ReportConstants.ADD_JOBCARD_REPORT.equals(from)){
			mav = new ModelAndView("jobcard");	
		    mav.addObject(ReportConstants.SPARE_DETAIL,
		    		spareDetail);
		} else if(ReportConstants.UPDATE_JOBCARD_REPORT.equals(from)) {
			mav = new ModelAndView("updatejobcard");	
		}
		mav.addObject("fromParam", from);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return mav;
} 

@RequestMapping("addJobcardReport.do")
public ModelAndView getJobCardReport(HttpServletRequest request, HttpServletResponse response,JobCardDetails jobCardDetails)
{
	ModelAndView mav = null;

	try {
		System.out.println("@ controller.....");
		log.info("Entered addJobcardReport ..");
		//reportFilter.setFormatType(FormatType.HTML);
		 LinkedHashMap<String, Float> spareDetail = racesService
                 .getSparesDetails();
		String from = jobCardDetails.getFrom();
		List<SoldSpares> soldDetails = (List<SoldSpares>) jobCardDetails
				.getSpareDetails();
		int count = soldDetails.size();
		log.info("size of sold detail: " + count);
		String message = racesService.addJobcardDetail(jobCardDetails);
		if(message.equals("success") && ReportConstants.ADD_JOBCARD_REPORT.equals(from)){
			mav = new ModelAndView("successjobcard");	
		    mav.addObject(ReportConstants.SPARE_DETAIL,
		    		spareDetail);
		    mav.addObject("spareDetail",
		    		soldDetails);
		   //mav.addObject("count", count);
		    mav.addObject("successmessage", "successfully saved");
		} else {
			mav = new ModelAndView("successjobcard");	
		    mav.addObject(ReportConstants.SPARE_DETAIL,
		    		spareDetail);
		    mav.addObject("spareDetail",
		    		soldDetails);
		   //mav.addObject("count", count);
		    mav.addObject("failuremessage", "Detail is not saved due to duplication of job card number");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}

	return mav;
} 

@RequestMapping("updateJobcardReport.do")
public ModelAndView getJobCardReportForUpdate(HttpServletRequest request, HttpServletResponse response,JobCardDetails jobCardDetails)
{
	ModelAndView mav = null;

	try {
		System.out.println("@ controller.....");
		log.info("Entered Update JobCard ..");
		//reportFilter.setFormatType(FormatType.HTML);
		 LinkedHashMap<String, Float> spareDetail = racesService
                 .getSparesDetails();
		 log.info("GET JOBCARD DETAILS FOR ::: ->"+jobCardDetails.getJobcardNumber()+"<-");
		 //racesService.getReportForParticularJobcard(jobCardDetails);
		 racesService.updateJobCardDetails(jobCardDetails);
		 String from = jobCardDetails.getFrom();
		
		List<SoldSpares> soldDetails = (List<SoldSpares>) jobCardDetails
				.getSpareDetails();
		int count = soldDetails.size();
		log.info("size of sold detail: " + count);
		
		String message = racesService.addJobcardDetail(jobCardDetails);
		
		if(message.equals("success") && ReportConstants.UPDATE_JOBCARD_REPORT.equals(from)){
			mav = new ModelAndView("success update jobcard");	
		    mav.addObject(ReportConstants.SPARE_DETAIL,
		    		spareDetail);
		   
		    mav.addObject("spareDetail",
		    		soldDetails); 
		   mav.addObject("count", count);
		   
		   mav.addObject("successmessage", "successfully Updated");
		} else {
			mav = new ModelAndView("success update jobcard");	
		    mav.addObject(ReportConstants.SPARE_DETAIL,
		    		spareDetail);
		   
		    mav.addObject("spareDetail",
		    		soldDetails);
		   mav.addObject("count", count);
		 
		   mav.addObject("failuremessage", "Detail is not Updated due to duplication of job card number");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return mav;
} 

@RequestMapping("rerunReport.do")
public ModelAndView rerunEventReport(HttpServletRequest request,
        HttpServletResponse response, ReportFilter reportFilter) {
    long time = System.currentTimeMillis();
    ModelAndView mav = new ModelAndView(ReportConstants.EXCEPTION_PAGE);
    try {
        log.info("Entering rerun Event report,"
                + " getting new report for user search : " + time);
        //reportFilter.setFrom(ReportConstants.LINK);
        reportFilter.setForCurrentMonth("2008-02-01");
        reportFilter.setFormatType(FormatType.HTML);
        byte[] byteArray = getEventReportBytes(reportFilter);
        String eventReport = new String(byteArray, ReportConstants.CHAR_SET);
        response.setCharacterEncoding(ReportConstants.CHAR_SET);
        response.setContentType(ReportConstants.HTML_CONTENT_TYPE);
        response.getWriter().write(eventReport);

    } catch (UnsupportedEncodingException encodingException) {
        log.error("UnsupportedEncodingException while getting reports.",
                encodingException);

    } catch (IOException ioException) {
        log.error("IO Exception while getting report for event.",
                ioException);
        mav.addObject(ReportConstants.ERROR_MESSAGE,
                "IO Exception while getting report for event.");
        return mav;
    }
    return null;
}


@RequestMapping("authenticateUser.do")
public ModelAndView doAuthentication(HttpServletRequest request, HttpServletResponse response)
{   ModelAndView mav = null;
    mav = new ModelAndView("raceshome");
	String username = request.getParameter("userName");
	String password = request.getParameter("password");
	System.out.println("@ Authentication.....username"+username); 
	log.info("Authentication.....");
	String message = racesService.getAuthenticationValue(username,password);
	if(message == "FAIL") {
		mav = new ModelAndView("index");
		mav.addObject("message", "No User Found");
	}
	return mav;
}


@RequestMapping("racesHome.do")
public ModelAndView loadLoginpage(HttpServletRequest request, HttpServletResponse response)
{
	System.out.println("@ Loading login page....."); 
	return new ModelAndView("index");
}


@RequestMapping("forgotPassword")
public ModelAndView forgotPassword()
{
	log.info("Forgot Password .....");
	System.out.println("@ Forgot Password....."); 
	racesService.getForgotPassword("");
	return new ModelAndView("test");
}
@RequestMapping("createSalesReport.do")
public void createUsageTrend(HttpServletRequest request,
        HttpServletResponse response) {
    long startTime = System.currentTimeMillis();
    log.info("Creating Sales Report.--------" + startTime);
    try {
        response.setContentType(ReportConstants.HTML_CONTENT_TYPE);
       // response.getOutputStream().write(
        		//racesService.createUsageTrend(FormatType.IMAGE)
                //        .toByteArray());
        response.flushBuffer();
    } catch (IOException ioException) {
        log.error("IO exception has occurred.", ioException);
    }
    log.info("Done! Creating Sales Report.-------- ");
}

@RequestMapping("getSalesReportChart.do")
public ModelAndView getServiceReportChart(HttpServletRequest request,
        HttpServletResponse response) {
    long startTime = System.currentTimeMillis();
    log.info("Entering getImage to get Sales report chart image.----"
            + startTime);
    response.setContentType(ReportConstants.IMAGE_TYPE);
    ModelAndView mav = new ModelAndView(ReportConstants.EXCEPTION_PAGE);
    try {
        String usageTrendChart = ReportConstants.USER_HOME + usageTrendFile;
        InputStream inputStream = new BufferedInputStream(
                new FileInputStream(usageTrendChart));
        ImageIO.write(ImageIO.read(inputStream),
                ReportConstants.FORMAT_TYPE, response.getOutputStream());
        inputStream.close();
        log.info("Writing image into output stream.");
    } catch (FileNotFoundException filesException) {
        log.error("Image not found in the respective location.",
                filesException);
    } catch (IOException ioException) {
        log.error("Unable to write image.", ioException);
        mav.addObject(ReportConstants.ERROR_MESSAGE,
                "IO Exception while getting report for event.");
        return mav;
    }
    return null;
}

@RequestMapping("createServiceReport.do")
public void createServiceReport(HttpServletRequest request,
        HttpServletResponse response) {
    long startTime = System.currentTimeMillis();
    log.info("Creating Service Report.--------" + startTime);
    System.out.println("createServiceReport.do --- Started");
    try {
        response.setContentType(ReportConstants.HTML_CONTENT_TYPE);
        response.getOutputStream().write(
        		racesService.createUsageTrend(FormatType.IMAGE)
                        .toByteArray());
        response.flushBuffer();
    } catch (IOException ioException) {
        log.error("IO exception has occurred.", ioException);
    }
    catch(java.lang.NullPointerException NPE)
    {
    	System.out.println("Exception at createServiceReport.do : "+NPE);
    }
    log.info("Done! Creating Service Report.-------- ");
    System.out.println("createServiceReport.do ----- Completed");
}

@RequestMapping("getServiceReportChart.do")
public ModelAndView getUsageTrendChart(HttpServletRequest request,
        HttpServletResponse response) {
    long startTime = System.currentTimeMillis();
    log.info("Entering getImage to get Service report chart image.----"
            + startTime);
    System.out.println("SASHI 1");
    System.out.println("getServiceReportChart.do : STARTED");
    response.setContentType(ReportConstants.IMAGE_TYPE);
    ModelAndView mav = new ModelAndView(ReportConstants.EXCEPTION_PAGE);
    try {
        String usageTrendChart = ReportConstants.USER_HOME + usageTrendFile;
        InputStream inputStream = new BufferedInputStream(
                new FileInputStream(usageTrendChart));
        ImageIO.write(ImageIO.read(inputStream),
                ReportConstants.FORMAT_TYPE, response.getOutputStream());
        inputStream.close();
        log.info("Writing image into output stream.");
        System.out.println("Writing image into output stream.");
        System.out.println("SASHI 2");
    } catch (FileNotFoundException filesException) {
        log.error("Image not found in the respective location.",
                filesException);
    } catch (IOException ioException) {
        log.error("Unable to write image.", ioException);
        mav.addObject(ReportConstants.ERROR_MESSAGE,
                "IO Exception while getting report for event.");
        return mav;
    }
    return null;
}

@RequestMapping("exportReport.do")
public void exportEventReport(ReportFilter reportFilter,
        HttpServletRequest request, HttpServletResponse response) {
    long startTime = System.currentTimeMillis();
    log.info("Entering into exportReportForEvent() method -----"
            + startTime);
    try {
        FormatType format = reportFilter.getFormatType();
        String headerInfo = getHeaderInfo(format);
        //reportFilter.setForCurrentMonth("2008-02-01");
        response.setHeader(ReportConstants.HEADER_INFO, headerInfo);
        String contentType = getContentType(format);
        response.setContentType(contentType);
        // Getting event report from service based on user selection.
        //reportFilter.setFrom(ReportConstants.EXPORT_REPORT);
        byte[] eventReportBytes;
            eventReportBytes = getEventReportBytes(reportFilter);
        switch (format) {
        case HTML:
            response.getOutputStream().write(eventReportBytes);
            break;
        case PDF:
            response.getOutputStream().write(eventReportBytes);
            break;
        case CSV:
            response.getOutputStream().write(239);
            response.getOutputStream().write(187);
            response.getOutputStream().write(191);
            response.getOutputStream().write(eventReportBytes);
            break;
		default:
			break;
        }
    } catch (IOException ioException) {
        log.error("IO Exception while exporting event report.",
                ioException);
    }
}

@RequestMapping("printReport.do")
public void printEventReport(ReportFilter reportFilter,
        HttpServletRequest request, HttpServletResponse response) {
    long startTime = System.currentTimeMillis();
    log.info("Entering print event report.------" + startTime);
    reportFilter.setForCurrentMonth("2008-02-01");
    reportFilter.setFormatType(FormatType.HTML);
   // reportFilter.setFrom(ReportConstants.EXPORT_REPORT);
    ByteArrayOutputStream eventReportStream;
    // report selection based on events
        eventReportStream = getEventReport(reportFilter);
    try {
        response.setContentType(ReportConstants.HTML_CONTENT_TYPE);
        response.setHeader(ReportConstants.HEADER_INFO,
                ReportConstants.HTML_HEADER_INFO);
        response.setCharacterEncoding(ReportConstants.CHAR_SET);
        response.getWriter().write(
                new String(eventReportStream.toByteArray(),
                        ReportConstants.CHAR_SET));
    } catch (IOException ioException) {
        log.error("IO Exception while printing event report. ",
                ioException);
    }
}

private byte[] getEventReportBytes(ReportFilter reportFilter) {
    log.info("Requesting ervent report as stream.");
    // Getting event report as stream and returning as byte array.
    ByteArrayOutputStream eventReportStream = getEventReport(reportFilter);
    log.info("Returning event report as byte array.");
    return eventReportStream.toByteArray();
}


private ByteArrayOutputStream getEventReport(ReportFilter reportFilter) {
    log.info("Entering get Event report to decide and request service to create an event report.");
    ByteArrayOutputStream eventReportStream = null;
        // Report for research area is done here.
        log.debug("getTopArticlesForEventByResearchArea() called.");
        eventReportStream = racesService
                .getPendingReport(reportFilter);
    log.info("Event report creation done.");
    return eventReportStream;
}


private String getContentType(FormatType formatType) {
    String contentType = null;
    switch (formatType) {
    case PDF:
        contentType = ReportConstants.PDF_CONTENT_TYPE;
        break;
    case HTML:
        contentType = ReportConstants.HTML_CONTENT_TYPE;
        break;
    case CSV:
        contentType = ReportConstants.CSV_CONTENT_TYPE;
        break;
    default:
        break;
    }
    return contentType;
}

private String getHeaderInfo(FormatType formatType) {
    String headerInfo = null;
    switch (formatType) {
    case PDF:
        headerInfo = ReportConstants.PDF_HEADER_INFO;
        break;
    case HTML:
        headerInfo = ReportConstants.HTML_HEADER_INFO;
        break;
    case CSV:
        headerInfo = ReportConstants.CSV_HEADER_INFO;
        break;
    default:
        break;
    }
    return headerInfo;
}

}
