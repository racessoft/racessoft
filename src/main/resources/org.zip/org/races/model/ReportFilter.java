package org.races.model;

import java.util.Date; 
import org.races.util.FormatType;

public class ReportFilter {
	String forCurrentMonth;
	public String getForCurrentMonth() {
		return forCurrentMonth;
	}
	public void setForCurrentMonth(String forCurrentMonth) {
		this.forCurrentMonth = forCurrentMonth;
	}
	String fromDate;
	String toDate;
	FormatType formatType;
	String from;
	String navLink;
	public String getNavLink() {
		return navLink;
	}
	public void setNavLink(String navLink) {
		this.navLink = navLink;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public FormatType getFormatType() {
		return formatType;
	}
	public void setFormatType(FormatType formatType) {
		this.formatType = formatType;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

}
