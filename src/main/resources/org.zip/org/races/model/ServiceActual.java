package org.races.model;

import java.util.Date;

public class ServiceActual {
String chasisnumber;
public String getChasisnumber() {
	return chasisnumber;
}
public void setChasisnumber(String chasisnumber) {
	this.chasisnumber = chasisnumber;
}
public Date getFirstServiceDate() {
	return firstServiceDate;
}
public void setFirstServiceDate(Date firstServiceDate) {
	this.firstServiceDate = firstServiceDate;
}
public int getFirstServiceHours() {
	return firstServiceHours;
}
public void setFirstServiceHours(int firstServiceHours) {
	this.firstServiceHours = firstServiceHours;
}
public Date getSecondServiceDate() {
	return secondServiceDate;
}
public void setSecondServiceDate(Date secondServiceDate) {
	this.secondServiceDate = secondServiceDate;
}
public int getSecondServiceHours() {
	return secondServiceHours;
}
public void setSecondServiceHours(int secondServiceHours) {
	this.secondServiceHours = secondServiceHours;
}
public Date getThirdServiceDate() {
	return thirdServiceDate;
}
public void setThirdServiceDate(Date thirdServiceDate) {
	this.thirdServiceDate = thirdServiceDate;
}
public int getThirdServiceHours() {
	return thirdServiceHours;
}
public void setThirdServiceHours(int thirdServiceHours) {
	this.thirdServiceHours = thirdServiceHours;
}
public Date getFourthServiceDate() {
	return fourthServiceDate;
}
public void setFourthServiceDate(Date fourthServiceDate) {
	this.fourthServiceDate = fourthServiceDate;
}
public int getFourthServiceHours() {
	return fourthServiceHours;
}
public void setFourthServiceHours(int fourthServiceHours) {
	this.fourthServiceHours = fourthServiceHours;
}
public Date getFifthServiceDate() {
	return fifthServiceDate;
}
public void setFifthServiceDate(Date fifthServiceDate) {
	this.fifthServiceDate = fifthServiceDate;
}
public int getFifthServiceHours() {
	return fifthServiceHours;
}
public void setFifthServiceHours(int fifthServiceHours) {
	this.fifthServiceHours = fifthServiceHours;
}
public Date getSixthServiceDate() {
	return sixthServiceDate;
}
public void setSixthServiceDate(Date sixthServiceDate) {
	this.sixthServiceDate = sixthServiceDate;
}
public int getSixthServiceHours() {
	return sixthServiceHours;
}
public void setSixthServiceHours(int sixthServiceHours) {
	this.sixthServiceHours = sixthServiceHours;
}
public Date getSeventhServiceDate() {
	return seventhServiceDate;
}
public void setSeventhServiceDate(Date seventhServiceDate) {
	this.seventhServiceDate = seventhServiceDate;
}
public int getSeventhServiceHours() {
	return seventhServiceHours;
}
public void setSeventhServiceHours(int seventhServiceHours) {
	this.seventhServiceHours = seventhServiceHours;
}
public Date getEigthServiceDate() {
	return eigthServiceDate;
}
public void setEigthServiceDate(Date eigthServiceDate) {
	this.eigthServiceDate = eigthServiceDate;
}
public int getEigthServiceHours() {
	return eigthServiceHours;
}
public void setEigthServiceHours(int eigthServiceHours) {
	this.eigthServiceHours = eigthServiceHours;
}
Date firstServiceDate;
int firstServiceHours;
Date secondServiceDate;
int secondServiceHours;
Date thirdServiceDate;
int thirdServiceHours;
Date fourthServiceDate;
int fourthServiceHours;

Date fifthServiceDate;
int fifthServiceHours;
Date sixthServiceDate;
int sixthServiceHours;
Date seventhServiceDate;
int seventhServiceHours;
Date eigthServiceDate;
int eigthServiceHours;



}
